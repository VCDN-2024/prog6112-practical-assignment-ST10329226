package studentmanagementapp;


 //Title: Library Management System
 //Author: Emily Carter
 //Date: September 3, 2024
 //Version: 1.0
 // Available: https://www.codeexamples.org
 

import java.util.ArrayList;
import java.util.Scanner;

public class StudentManagementApp {
    
    // ArrayList to store student objects
    ArrayList<Student> students = new ArrayList<>();
    
    public static void main(String[] args) {
        StudentManagementApp app = new StudentManagementApp();
        app.launchMenu();
    }

    public void launchMenu() {
        Scanner scanner = new Scanner(System.in);
        String input = "";
        
        while (!input.equals("5")) {
            System.out.println("STUDENT MANAGEMENT APPLICATION");
            System.out.println("******************************");
            System.out.println("Enter (1) to launch menu or any other key to exit");
            input = scanner.nextLine();
            
            if (input.equals("1")) {
                displayMenu();
            } else {
                System.out.println("Exiting application...");
                break;
            }
        }
        scanner.close();
    }

    public void displayMenu() {
        Scanner scanner = new Scanner(System.in);
        String choice = "";
        
        while (!choice.equals("5")) {
            System.out.println("Please select one of the following menu items:");
            System.out.println("(1) Capture a new student.");
            System.out.println("(2) Search for a student.");
            System.out.println("(3) Delete a student.");
            System.out.println("(4) Print student report.");
            System.out.println("(5) Exit Application.");
            
            choice = scanner.nextLine();
            
            switch (choice) {
                case "1":
                    captureStudent();
                    break;
                case "2":
                    searchStudent();
                    break;
                case "3":
                    deleteStudent();
                    break;
                case "4":
                    printStudentReport();
                    break;
                case "5":
                    System.out.println("Exiting application...");
                    scanner.close();
                System.exit(0); // This exits the application completely
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.close();
    }
public void captureStudent(String id, String name, int age, String email, String course) {
    // Create a new Student object and add it to the list
    students.add(new Student(id, name, age, email, course));
    System.out.println("Student details have been successfully saved.");
}
    
    public void captureStudent() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("*********************");

        System.out.print("Enter the student id: ");
        String id = scanner.nextLine();

        System.out.print("Enter the student name: ");
        String name = scanner.nextLine();

        int age = getValidStudentAge(scanner);

        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();

        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();

        students.add(new Student(id, name, age, email, course));
        System.out.println("Student details have been successfully saved.");
    }

    public Student searchStudent(String id) {
    for (Student student : students) {
        if (student.getId().equals(id)) {
            return student;
        }
    }
    return null; // Return null if no student is found with the given id
}
    
    public void searchStudent() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the student id to search: ");
        String id = scanner.nextLine();
        Student student = findStudentById(id);
        if (student != null) {
            System.out.println("STUDENT ID: " + student.getId());
            System.out.println("STUDENT NAME: " + student.getName());
            System.out.println("STUDENT AGE: " + student.getAge());
            System.out.println("STUDENT EMAIL: " + student.getEmail());
            System.out.println("STUDENT COURSE: " + student.getCourse());
        } else {
            System.out.println("Student with Student ID: " + id + " was not found!");
        }
    }

    public void deleteStudent() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the student id to delete: ");
        String id = scanner.nextLine();

        Student student = findStudentById(id);

        if (student != null) {
            System.out.print("Are you sure you want to delete student " + id + " from the system? Yes (y) to delete: ");
            String confirmation = scanner.nextLine();
            if (confirmation.equalsIgnoreCase("y")) {
                students.remove(student);
                System.out.println("Student with Student ID: " + id + " WAS deleted!");
            }
        } else {
            System.out.println("Student with Student ID: " + id + " was not found!");
        }
    }

    public void printStudentReport() {
        if (students.isEmpty()) {
            System.out.println("No students available.");
            return;
        }
        
        int count = 1;
        for (Student student : students) {
            System.out.println("STUDENT " + count);
            System.out.println("----------------------------");
            System.out.println("STUDENT ID: " + student.getId());
            System.out.println("STUDENT NAME: " + student.getName());
            System.out.println("STUDENT AGE: " + student.getAge());
            System.out.println("STUDENT EMAIL: " + student.getEmail());
            System.out.println("STUDENT COURSE: " + student.getCourse());
            System.out.println("----------------------------");
            count++;
        }
    }

    int getValidStudentAge(Scanner scanner) {
        int age;
        while (true) {
            System.out.print("Enter the student age: ");
            String ageInput = scanner.nextLine();
            try {
                age = Integer.parseInt(ageInput);
                if (age >= 16) {
                    break;
                } else {
                    System.out.println("You have entered an incorrect student age!!! Please re-enter the student age >>");
                }
            } catch (NumberFormatException e) {
                System.out.println("You have entered an incorrect student age!!! Please re-enter the student age >>");
            }
        }
        return age;
    }

    public Student findStudentById(String id) {
        for (Student student : students) {
            if (student.getId().equals(id)) {
                return student;
            }
        }
        return null;
    }   

    private static class student {

        public student() {
        }
    }
}

class Student {
    public String id;
    public String name;
    public int age;
    public String email;
    public String course;

    public Student(String id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }
}
