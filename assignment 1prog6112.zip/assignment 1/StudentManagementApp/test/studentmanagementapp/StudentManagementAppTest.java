
package studentmanagementapp;
import java.util.Scanner;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import studentmanagementapp.Student;
import studentmanagementapp.StudentManagementApp;

public class StudentManagementAppTest {

    private StudentManagementApp app;

    @BeforeEach
    public void setUp() {
        app = new StudentManagementApp();
    }

    @Test
    public void TestSaveStudent() {
        // Create a sample student
        Student student = new Student("123", "John Doe", 20, "john.doe@example.com", "Computer Science");

        // Save the student
        app.captureStudent(student.getId(), student.getName(), student.getAge(), student.getEmail(), student.getCourse());

        // Assert that the student was added
        assertEquals(1, app.students.size());
        assertEquals(student, app.students.get(0));
    }

    @Test
    public void TestSearchStudent() {
        // Create a sample student
        Student student = new Student("123", "John Doe", 20, "john.doe@example.com", "Computer Science");
        app.students.add(student);

        // Search for the student
        Student foundStudent = app.searchStudent(student.getId());

        // Assert that the correct student was found
        assertEquals(student, foundStudent);
    }

    @Test
    public void TestSearchStudent_StudentNotFound() {
        // Search for a non-existent student
        Student foundStudent = app.searchStudent("999");

        // Assert that no student was found
        assertNull(foundStudent);
    }

    @Test
    public void TestDeleteStudent() {
        // Create a sample student
        Student student = new Student("123", "John Doe", 20, "john.doe@example.com", "Computer Science");
        app.students.add(student);

        // Delete the student
        app.deleteStudent(student.getId());

        // Assert that the student was removed
        assertEquals(0, app.students.size());
    }

    @Test
    public void TestDeleteStudent_StudentNotFound() {
        // Attempt to delete a non-existent student
        app.deleteStudent("999");

        // Assert that no student was found
        // (You might want to add a specific message or check for a warning)
    }

    @Test
    public void TestStudentAge_StudentAgeValid() {
        // Test with various valid ages
        int[] validAges = {16, 17, 18, 20, 30, 50};
        for (int age : validAges) {
            int actualAge = app.getValidStudentAge(new Scanner(String.valueOf(age)));
            assertEquals(age, actualAge);
        }
    }

    @Test
    public void TestStudentAge_StudentAgeInvalid() {
        // Test with ages less than 16
       int[] invalidAges = {15, 14, 13, 12, 11, 10};
    for (int age : invalidAges) {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            app.getValidStudentAge(new Scanner(String.valueOf(age)));
        });

        // You can add more assertions here to check specific properties of the exception
        // For example, you could check the exception message:
        assertEquals("Invalid student age. Age must be 16 or older.", exception.getMessage());
            
        }
    }

    @Test
    public void TestStudentAge_StudentAgeInvalidCharacter() {
        // Test with various invalid characters
         String[] invalidInputs = {"abc", "123a", "12.3", "-10", " "};
    for (String input : invalidInputs) {
        NumberFormatException exception = assertThrows(NumberFormatException.class, () -> {
            app.getValidStudentAge(new Scanner(input));
        });

        // You can add more assertions here to check specific properties of the exception
        // For example, you could check the exception message:
        assertEquals("Invalid input: " + input, exception.getMessage());
        }
    }
}