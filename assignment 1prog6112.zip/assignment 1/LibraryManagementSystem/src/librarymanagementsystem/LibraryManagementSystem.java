
package librarymanagementsystem;

import java.util.Scanner;


 // Title: Library Management System
 //Author: Alex Johnson
 //Date: September 1, 2024
 //Version: 1.0
 //Available: https://www.example-coding-site.com
 
public class LibraryManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Library library = new Library();

        // Main loop for user interface
        while (true) {
            System.out.println("1. Add Book");
            System.out.println("2. Remove Book");
            System.out.println("3. Search Book");
            System.out.println("4. Display Books");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            // Handle user choice
            switch (choice) {
                case 1:
                    library.addBook(); // Add a new book to the library
                    break;
                case 2:
                    library.removeBook(); // Remove a book from the library
                    break;
                case 3:
                    library.searchBook(); // Search for a book by title, author, or ISBN
                    break;
                case 4:
                    library.displayBooks(); // Display all books in the library
                    break;
                case 5:
                    System.out.println("Exiting...");
                    System.exit(0);  //Exit the program
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
// Represents a book with title, author, ISBN, and publication year.
class Book {
    private String title;
    private String author;
    private String isbn;
    private int publicationYear;

    // Constructor
    public Book(String title, String author,String isbn, int publicationYear) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.publicationYear = publicationYear;
    }

    // Getters and setters
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getIsbn() {
        return isbn;
    }

    public int getPublicationYear() {
        return publicationYear;  }

    @Override
    public String toString() {
        return "Title: " + title + ", Author: " + author + ", ISBN: " + isbn + ", Publication Year: " + publicationYear;
    }
}

class Library {
    private Book[] books;
    private int bookCount;

    // Constructor
    public Library() {
        books = new Book[100];
        bookCount = 0;
    }

    // Add a book to the library
    public void addBook() {
        if (bookCount >= books.length) {
            System.out.println("Library is full. Cannot add more books.");
            return;
        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter book title: ");
        String title = scanner.nextLine();
        System.out.print("Enter author's name: ");
        String author = scanner.nextLine();
        System.out.print("Enter ISBN: ");
        String isbn = scanner.nextLine();
        System.out.print("Enter publication year: ");
        int publicationYear = scanner.nextInt();

        books[bookCount] = new Book(title, author, isbn, publicationYear);
        bookCount++;
        System.out.println("Book added successfully.");
    }

    // Remove a book from the library by ISBN
    public void removeBook() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter ISBN of the book to remove: ");
        String isbn = scanner.nextLine();

        int index = findBookIndexByISBN(isbn);
        if (index != -1) {
            System.arraycopy(books, index + 1, books, index, bookCount - index - 1);
            bookCount--;
            System.out.println("Book removed successfully.");
        } else {
            System.out.println("Book not found.");
        }
    }

    // Search for a book by title, author, or ISBN
    public void searchBook() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter search term (title, author, or ISBN): ");
        String searchTerm = scanner.nextLine();

        boolean found = false;
        for (int i = 0; i < bookCount; i++) {
            if (books[i].getTitle().equalsIgnoreCase(searchTerm) ||
                    books[i].getAuthor().equalsIgnoreCase(searchTerm) ||
                    books[i].getIsbn().equalsIgnoreCase(searchTerm)) {
                System.out.println(books[i]);
                found = true;
            }
        }

        if (!found) {
            System.out.println("Book not found.");
        }
    }

    // Display all books in the library
    public void displayBooks() {
        if (bookCount == 0) {
            System.out.println("Library is empty.");
        } else {
            for (int i = 0; i < bookCount; i++) {
                System.out.println(books[i]);
            }
        }
    }

    // Helper method to find the index of a book by ISBN
    private int findBookIndexByISBN(String isbn) {
        for (int i = 0; i < bookCount; i++) {
            if (books[i].getIsbn().equalsIgnoreCase(isbn)) {
                return i;
            }
        }
        return -1;
    }
}
