/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LibraryTest {
    private Library library;

    @BeforeEach
    public void setUp() {
        library = new Library();
    }

    @Test
    public void testAddBook() {
        // Test adding a book
        library.addBook("Book Title", "Author Name", "ISBN123", 2024);
        assertEquals(1, library.bookCount);
        assertEquals("Book Title", library.books[0].getTitle());
    }

    @Test
    public void testAddBookWhenLibraryIsFull() {
        // Fill the library with books
        for (int i = 0; i < Library.MAX_BOOKS; i++) {
            library.addBook("Book " + i, "Author " + i, "ISBN" + i, 2024);
        }

        // Try adding another book
        assertThrows(LibraryException.class, () -> library.addBook("New Book", "New Author", "ISBN456", 2025));
    }

    @Test
    public void testRemoveBook() {
        // Add a book
        library.addBook("Book Title", "Author Name", "ISBN123", 2024);

        // Remove the book
        library.removeBook("ISBN123");
        assertEquals(0, library.bookCount);
    }

    @Test
    public void testRemoveBookWhenBookNotFound() {
        // Try removing a non-existent book
        assertThrows(LibraryException.class, () -> library.removeBook("ISBN456"));
    }

    @Test
    public void testSearchBookByTitle() {
        // Add a book
        library.addBook("Book Title", "Author Name", "ISBN123", 2024);

        // Search by title
        Book foundBook = library.searchBook("Book Title");
        assertEquals("Book Title", foundBook.getTitle());
    }

    @Test
    public void testSearchBookByAuthor() {
        // Add a book
        library.addBook("Book Title", "Author Name", "ISBN123", 2024);

        // Search by author
        Book foundBook = library.searchBook("Author Name");
        assertEquals("Book Title", foundBook.getTitle());
    }

    @Test
    public void testSearchBookByISBN() {
        // Add a book
        library.addBook("Book Title", "Author Name", "ISBN123", 2024);

        // Search by ISBN
        Book foundBook = library.searchBook("ISBN123");
        assertEquals("Book Title", foundBook.getTitle());
    }

    @Test
    public void testSearchBookWhenBookNotFound() {
        // Search for a non-existent book
        Book foundBook = library.searchBook("Non-existent Book");
        assertNull(foundBook);
    }

    @Test
    public void testDisplayBooks() {
        // Add multiple books
        library.addBook("Book 1", "Author 1", "ISBN123", 2024);
        library.addBook("Book 2", "Author 2", "ISBN456", 2025);

        // Display books and verify the output (you can use a mocking framework or assert the correct number of books are displayed)
        // ...
    }
}
